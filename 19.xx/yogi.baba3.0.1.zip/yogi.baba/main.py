import sys
from urllib.parse import urlencode, parse_qs
import xbmcaddon
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
import requests
import re

# Get the plugin url in plugin:// notation.
_URL = sys.argv[0]
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])

Yogi_URI = "http://tamilyogi.beer/category/"

def addLog(message, level="notice"):
    if level == "error":
        xbmc.log(str(message), level=xbmc.LOGERROR)
    else:
        xbmc.log(str(message), level=xbmc.LOGINFO)

def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :return: plugin call URL
    :rtype: str
    """
    return '{}?{}'.format(_URL, urlencode(kwargs))


def get_categories():
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or API.

    .. note:: Consider using `generator functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :return: The list of video categories
    :rtype: set
    """
    categories_list = {"NewMovies", "HDMovies", "Dubbed_Movies", "Web_Series"}
    return categories_list

def http_get(url):
    headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.74 Safari/537.36'}
    try:
        r = requests.get(url, headers=headers, cookies=None).content
        return r.decode('utf-8')
    except requests.exceptions.RequestException as e:
        return ''

def movie_dict_prepare(title, img, url, genre):
    movie_dict = {
        'name': title,
        'thumb': img,
        'video': url,
        'genre': genre
    }
    return movie_dict

def unicode_removal(string):
    strencode = string.encode("ascii", "ignore")
    strdecode = strencode.decode()
    return strdecode

def title_extract(genre, next_page=False):
    title_tmp = set()
    movie_database = []
    movie_url = ""
    movie_title = ""
    movie_img = ""
    if next_page:
        uri_yogi = next_page
    else:
        if genre == "NewMovies":
            uri_yogi = Yogi_URI+ "tamilyogi-full-movie-online/"
        elif genre == "HDMovies":
            uri_yogi = Yogi_URI+ "tamilyogi-bluray-movies/"
        elif genre == "Dubbed_Movies":
            uri_yogi = Yogi_URI+ "tamilyogi-dubbed-movies-online/"
        elif genre == "Web_Series":
            uri_yogi = Yogi_URI+ "tamil-web-series/"
        else:
            return

    home_page = http_get(uri_yogi)

    soup = BeautifulSoup(home_page, "html.parser")
    class_cover = soup.find_all(class_="cover")
    for cover in class_cover:
        try:
            movie_url = str(unicode_removal(cover.find('a')['href']))
            movie_title = str(unicode_removal(re.search(r"([\w\d\s]*)", cover.find('a')['title']).group(1)))
            movie_img = str(unicode_removal(cover.find('img')['src']))
        except Exception as e:
            addLog("Title_Extract error", "error")
            addLog(movie_url)
            addLog(str(e))
            continue

        if movie_title in title_tmp:
            continue

        add_dict = movie_dict_prepare(movie_title, movie_img, movie_url, genre)
        movie_database.append(add_dict)

    next_page = soup.find(class_="next page-numbers")
    if next_page:
        next_pg_dict = movie_dict_prepare(">>Next Page", "", next_page.get('href'), genre)
        movie_database.append(next_pg_dict)

    main_menu_dict = movie_dict_prepare(">>Main Menu", "", "", "")
    movie_database.append(main_menu_dict)

    return movie_database

def get_video_mp4(movie_url):
    try:
        movie_page = http_get(movie_url)
        if_soup = BeautifulSoup(movie_page, "html.parser")
        iframe_tag = if_soup.find("iframe")['src']
        if not iframe_tag:
            return
        video_page = http_get(iframe_tag)
        video_link = re.findall(r"https?:\/\/[\.\/\w\d]*.mp4", video_page)[0]
        return video_link
    except Exception as e:
        addLog("get_video_mp4 Error", "error")
        addLog(movie_url)
        addLog(str(e), "error")
        return

def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    movie_dict = dict()
    xbmcplugin.setPluginCategory(_HANDLE, 'My Video Collection')
    xbmcplugin.setContent(_HANDLE, 'videos')
    categories = get_categories()
    for category in categories:
        list_item = xbmcgui.ListItem(label=category)
        movie_dict[category] = title_extract(category)
        addLog(movie_dict[category][0]['thumb'], level="notice")
        list_item.setArt({'thumb': movie_dict[category][0]['thumb'],
                          'icon': movie_dict[category][0]['thumb'],
                          'fanart': movie_dict[category][0]['thumb']})
        list_item.setInfo('video', {'title': category,
                                    'genre': category,
                                    'mediatype': 'video'})
        url = get_url(action='listing', category=category)
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    xbmcplugin.endOfDirectory(_HANDLE)

def list_videos(category, next_page=False):
    xbmcplugin.setPluginCategory(_HANDLE, category)
    xbmcplugin.setContent(_HANDLE, 'videos')
    if next_page:
        videos = title_extract(category, next_page)
    else:
        videos = title_extract(category)
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['name'])
        list_item.setInfo('video', {'title': video['name'],
                                    'genre': video['genre'],
                                    'mediatype': 'video'})
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', video=video['video'])
        is_folder = False
        if video['name'] == ">>Next Page":
            is_folder = True
            url = get_url(action='nextpage', category=category, video=video['video'])
        elif video['name'] == ">>Main Menu":
            is_folder = True
            url = get_url(action='mainmenu')
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    xbmcplugin.endOfDirectory(_HANDLE)

def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)

def router(paramstring):
    params = parse_qs(paramstring)
    video_link = ""
    if params:
        if params['action'][0] == 'listing':
            list_videos(params['category'][0])
        elif params['action'][0] == 'play':
            video_link = get_video_mp4(params['video'][0])
            if video_link:
                play_video(video_link)
            else:
                addLog("Unable to Source The Video")
        elif params['action'][0] == 'nextpage':
            list_videos(params['category'][0], params['video'][0])
        elif params['action'][0] == 'mainmenu':
            list_categories()
        else:
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])
