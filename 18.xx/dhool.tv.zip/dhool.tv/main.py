"""
plugin compatible with Kodi 19.x "Matrix" and above
"""
import sys
#from urllib.parse import urlencode, parse_qsl
from urllib import urlencode
from urlparse import parse_qs
import xbmcgui
import xbmcplugin
import xbmc

from bs4 import BeautifulSoup
#from HTMLParser import HTMLParser
import requests
import re


__url__ = sys.argv[0]
     # Get the plugin handle as an integer number.
__handle__ = int(sys.argv[1])

Yogi_URI = "https://www.tamildhool.net/"

def addLog(message, level="notice"):
    if level == "error":
        xbmc.log(str(message), level=xbmc.LOGERROR)
    else:
        xbmc.log(str(message), level=xbmc.LOGNOTICE)

def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :return: plugin call URL
    :rtype: str
    """
    return '{}?{}'.format(__url__, urlencode(kwargs))


def get_categories():
         """
         Get the list of video categories.
         Here you can insert some parsing code that retrieves
         the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
         from some site or server.
         :return: list
         """
         categories_list = {"VijayTV","ZeeTamil","SunTv","Colors"}
         return categories_list
         #return VIDEOS.keys()

def http_get(url):
    headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.74 Safari/537.36','referer':'https://www.tamildhool.net/'}
    try:
        r = requests.get(url, headers=headers, cookies=None).content
        return r
    except urllib2.URLError, e:
        return ''

def unicode_removal(string):
    strencode = string.encode("ascii", "ignore")
    strdecode = strencode.decode()
    return strdecode

def sub_program_extract(category,channel):
    program_dict = []
    Yogi_URI = "https://www.tamildhool.net/"

    if channel == 'VijayTV':
        Yogi_URI = Yogi_URI + "vijay-tv-programs/"
    elif channel == 'ZeeTamil':
        Yogi_URI = Yogi_URI + "zee-tamil-programs/"
    elif channel == 'SunTv':
        Yogi_URI = Yogi_URI + "sun-tv-programs/"
    elif channel == 'Colors':
        Yogi_URI = Yogi_URI + "colors-tamil-programs/"

    
    home_page = http_get(Yogi_URI)
    soup = BeautifulSoup(home_page,"html.parser")
    class_cover = soup.find_all(class_="wp-block-image")

    for cover in class_cover:
        movie_url = str(unicode_removal(cover.find('a')['href']))
        movie_title = str(unicode_removal((movie_url.rstrip()).split("/")[-2]))
        movie_catgeory = str(unicode_removal((movie_url.rstrip()).split("/")[-3]))
        movie_img = str(unicode_removal(cover.find('img')['data-lazy-src']))

        if movie_title:
            movie_title = movie_title.replace("-"," ")

        if not movie_img.startswith("https"):
            movie_img = "https:" + movie_img

        program_db = movie_title+";"+movie_url+";"+movie_img

        if movie_catgeory.endswith(category):
            program_dict.append(program_db)

    return program_dict

     


def list_sub_program(category,channel):
    #if not category or channel:
    #    addLog("list_sub_program arguments missing", level="notice")

    programs = sub_program_extract(category,channel)

    xbmcplugin.setPluginCategory(__handle__, 'My Video Collection')
    xbmcplugin.setContent(__handle__, 'videos')

    for program in programs:
        tmp_list = program.split(";")
        title = tmp_list[0]
        prg_url = tmp_list[1]
        img = tmp_list[2]

        list_item = xbmcgui.ListItem(label=title)
        addLog(title, level="notice")

        list_item.setArt({'thumb': img,
                          'icon': img,
                          'fanart': img})

        list_item.setInfo('video', {'title': title,
                                    'genre': category,
                                    'mediatype': 'video'})

        #url = '{0}?action=launch&category={1}&tv={2}'.format(__url__, program, channel)
        #url = get_url(action='subprogram', category=category)
        url = '{0}?action=listing&category={1}&prgurl={2}'.format(__url__, title, prg_url)

        is_folder = True

        xbmcplugin.addDirectoryItem(__handle__, url, list_item, is_folder)

    
    xbmcplugin.endOfDirectory(__handle__)   
    
def list_sub_categories(channel):
    """
    Create the list of video categories in the Kodi interface.
    :return: None
    """
    programs = {"serial","show"}    
    # Create a list for our items.
    listing = []
    # Iterate through categories
    for program in programs:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=program)
        url = '{0}?action=programtype&category={1}&tv={2}'.format(__url__, program, channel)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the listing as a 3-element tuple.
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(__handle__)

def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    :return: None
    """
    # Get video categories
    categories = get_categories()
    # Create a list for our items.
    listing = []
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        # Set a fanart image for the list item.
        # Here we use the same image as the thumbnail for simplicity's sake.
        #list_item.setProperty('fanart_image', VIDEOS[category][0]['thumb'])
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # http://mirrors.xbmc.org/docs/python-docs/15.x-isengard/xbmcgui.html#ListItem-setInfo
        #list_item.setInfo('video', {'title': category, 'genre': category})
        # Create a URL for the plugin recursive callback.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = '{0}?action=program&category={1}'.format(__url__, category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the listing as a 3-element tuple.
        listing.append((url, list_item, is_folder))
    # Add our listing to Kodi.
    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
    # instead of adding one by ove via addDirectoryItem.
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(__handle__)

def movie_dict_prepare(title,img,url):
    movie_dict = dict()
    movie_dict['name'] = title
    movie_dict['thumb'] = img
    movie_dict['video'] = url

    return movie_dict

def get_videdo_mp4(prg_url):
    media_url = None
    try:
        movie_page = http_get(prg_url)
        if_soup = BeautifulSoup(movie_page,"html.parser")
        iframe_tag = if_soup.find_all("iframe")
        for frame in iframe_tag:
            try:
                if frame["loading"] == "lazy":
                    media_url = frame["data-lazy-src"]
            except Exception as e:
                continue

        if not media_url:
            return

        load_media_url = http_get(media_url)
        video_link = re.search(r"file:.*(https?:\/\/.*.m3u8)\x22",load_media_url).group(1)
        try:
            domain = re.search(r"^https?:\/\/[^\/]+",video_link).group()
            highres_video = http_get(video_link)
            p720_link = re.search(r"\/.*\/720\/playlist\.m3u8",highres_video).group()
            p720_link = str(domain) + str(p720_link)
            if p720_link:
                video_link = p720_link

        except Exception as e:
            addLog("Unable to source 720p media file","notice")
            addLog(str(e),"notice")
            pass
        
        return video_link
    except Exception as e:
        addLog("get_videdo_mp4 Error","error")
        addLog(prg_url)
        addLog(str(e),"error")
        return

def video_extract(prg_url,next_page=False):
    movie_database = []
    movie_url = ""
    movie_title = ""
    movie_img = ""
    if next_page:
        prg_url = next_page

    

    home_page = http_get(prg_url)

    soup = BeautifulSoup(home_page,"html.parser")
    class_cover = soup.find_all(class_="post-thumb")
    for cover in class_cover:
        try:
            #movie_url = cover.find('a')['href']
            #movie_title = re.search(r"([\w\d\s]*)",cover.find('a')['title']).group(1)
            #movie_img = cover.find('img')['src']
            movie_url = str(unicode_removal(cover.find('a')['href']))
            movie_title = str(unicode_removal((movie_url.rstrip()).split("/")[-2]))
            movie_img = str(unicode_removal(cover.find('img')['data-lazy-src']))

            if not movie_img.startswith("https"):
                movie_img = "https:" + movie_img

        except Exception as e:
            addLog("Video_Extract error","error")
            addLog(movie_url)
            addLog(str(e))
            next

        add_dict = movie_dict_prepare(movie_title,movie_img,movie_url)
        movie_database.append(add_dict)

    #Next Page enumeration
    next_page = soup.find(class_="next page-numbers")
    if next_page:
        next_pg_dict = movie_dict_prepare(">>Next Page","",next_page.get('href'))
        movie_database.append(next_pg_dict)

    #MainMenu
    main_menu_dict = movie_dict_prepare(">>Main Menu","","")
    movie_database.append(main_menu_dict)
    
    return movie_database


def list_videos(prg_url,next_page=False):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(__handle__, prg_url)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(__handle__, 'videos')
    # Get the list of videos in the category.
    if next_page:
        videos = video_extract(prg_url,next_page)
    else:
        videos = video_extract(prg_url)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': video['name'],
                                    'mediatype': 'video'})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        if video['name'] == ">>Next Page":
            is_folder = True
            url = get_url(action='nextpage',video=video['video'])
        elif video['name'] == ">>Main Menu":
            is_folder = True
            url = get_url(action='mainmenu')
        
        #if is_folder:
        #    url = Yogi_URI+ "tamilyogi-bluray-movies/page/2"
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(__handle__, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    #xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(__handle__)


def play_video(path):
    """
    Play a video by the provided path.
    :param path: str
    :return: None
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(__handle__, True, listitem=play_item)

def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring
    :param paramstring:
    :return:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = parse_qs(paramstring)
    # Check the parameters passed to the plugin
    if params:
        if params['action'][0] == 'program':
            list_sub_categories(params['category'][0])
            #list_videos(params['category'][0])
        elif params['action'][0] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['prgurl'][0])
        elif params['action'][0] == 'play':
            video_link =  get_videdo_mp4(params['video'][0]) # extract m3u8 video_link
            if video_link:
                play_video(video_link)
            # Play a video from a provided URL.
            else:
                addLog("Unable to Source The Video")
        elif params['action'][0] == 'programtype':
            list_sub_program(params['category'][0],params['tv'][0])
        elif params['action'][0] == 'nextpage':
            list_videos(params['video'][0])
        elif params['action'][0] == 'mainmenu':
            list_categories()

    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
